#!/usr/bin/env sh
javac src/main/java/org.example/Main.java
java Main 3 20 5
java Main 3 20 3,5
Java Main 3 20 3v5
