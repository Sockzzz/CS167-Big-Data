# Lab 3

## Student information

* Full name: Marshall Jones
* E-mail: mjone032@ucr.edu
* UCR NetID: mjone032
* Student ID: 862062375

## Answers

- **(Q1)** Which of the following is the right way to call the `IsEven` function.

    - new Main.IsEven().apply(arg1);

- **(Q2)** Did the program compile?

    - After adding 'filter = 0' at the end of the function it does not compile anymore. 

- **(Q3)** If it does not work, what is the error message you get?
  - local variables referenced from a lambda expression must be final or effectively final