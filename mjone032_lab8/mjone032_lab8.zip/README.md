# Lab 8

## Student information

* Full name: Marshall Jones
* E-mail: mjone032@ucr.edu
* UCR NetID: mjone032
* Student ID: 862062375