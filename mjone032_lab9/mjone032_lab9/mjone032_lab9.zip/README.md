# Lab 9

## Student information

* Full name:
* E-mail:
* UCR NetID:
* Student ID:

## Answers

* (Q1) What is the schema of the file after loading it as a Dataframe

    ```text
    root
    |-- Timestamp: string (nullable = true)
    |-- Text: string (nullable = true)
    |-- Latitude: string (nullable = true)
    |-- Longitude: string (nullable = true)
    ```

* (Q2) Why in the second operation, convert, the order of the objects in the  tweetCounty RDD is (tweet, county) while in the first operation, count-by-county, the order of the objects in the spatial join result was (county, tweet)?

    ```text
    The first one pushes join on counties with tweets as its paramter,
    while in the second one the join pushes onto the tweets with counties as its parameters.
    ```

* (Q3) What is the schema of the tweetCounty Dataframe?

    ```text
    root
    |-- g: geometry (nullable = true)
    |-- Timestamp: string (nullable = true)
    |-- Text: string (nullable = true)
    |-- CountyID: string (nullable = true)
    ```

* (Q4) What is the schema of the convertedDF Dataframe?

    ```text
    root
    |-- CountyID: string (nullable = true)
    |-- keywords: array (nullable = true)
    |    |-- element: string (containsNull = true)
    |-- Timestamp: string (nullable = true)
    ```

* (Q5) For the tweets_10k dataset, what is the size of the decompressed ZIP file as compared to the converted Parquet file?

  | Size of the original decompressed file | Size of the Parquet file |
  | - | - |
  |  `788 KB` | `350 KB` |