// Replace <UCRNetID> with your UCR Net ID, not student ID.
package edu.ucr.cs.cs167.mjone032;

import java.io.IOException;
import java.util.Set;
import java.util.StringTokenizer;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import sun.security.jca.GetInstance;

import javax.print.attribute.standard.JobName;
import java.io.IOException;

public class Filter {
    public static void main(String[] args) throws Exception {
        //String fuck_off = args[0];

        //System.out.printf(fuck_off);
        //System.out.printf("asdhjbghjkabehjkgahbjksbgkhjasbhjkdbhjgadsbjhgbhjasdgbhjg");

        String inputPath = args[0];
        String outputPath = args[1];
        String desiredResponse = args[2];
        Configuration conf = new Configuration();

        //3.2
        conf.set("mykey",desiredResponse);

        Job job = Job.getInstance(conf, "filter");
        // TODO pass the desiredResponse code to the MapReduce program

        job.setJarByClass(Filter.class);
        job.setMapperClass(TokenizerMapper.class);
        job.setNumReduceTasks(0);
        job.setInputFormatClass(TextInputFormat.class);

        Path input = new Path(inputPath);
        FileInputFormat.addInputPath(job, input);
        Path output = new Path(outputPath);
        FileOutputFormat.setOutputPath(job, output);



        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }

    public static class TokenizerMapper extends
            Mapper<LongWritable, Text, NullWritable, Text> {

        //3.2
         String m;

        @Override
        protected void setup(Context context)
                throws IOException, InterruptedException {
            super.setup(context);
            // TODO add additional setup to your map task, if needed

            m = context.getConfiguration().get("mykey");

        }

        public void map(LongWritable key, Text value, Context context)
                throws IOException, InterruptedException {
            if (key.get() == 0) return; // Skip header line
            String[] parts = value.toString().split("\t");
            String responseCode = parts[5];

            if (responseCode.equals(m))
                context.write(NullWritable.get(), value);
        }
    }
}

