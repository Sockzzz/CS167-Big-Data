# Lab 1

## Student information
* Full name: Marshall Jones
* E-mail: mjone032@ucr.edu
* UCR NetID: mjone032
* Student ID: 862062375

## Answers

* (Q1) What is the name of the created directory? (A1) mjone032_lab1

* (Q2) What do you see at the console output? (A2) Hello World!

* (Q3) What do you see at the output? (A3) A long list of terminal warnings.

* (Q4) What is the output that you see at the console? (A4) Only two terminal warnings.

* (Q5) Does it run? Why or why not? (A5) It does not run due to exceptions from missing files.
